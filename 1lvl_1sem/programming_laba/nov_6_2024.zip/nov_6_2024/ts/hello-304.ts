//let msg:string = "Hello 304";
let msg = "Hello 304 from Egorov Alexander a.k.a. swrneko\n☆*:.｡.o(≧▽≦)o.｡.:*☆";
console.log(msg);
