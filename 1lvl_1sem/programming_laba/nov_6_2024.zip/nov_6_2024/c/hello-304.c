#include <stdio.h>

int main() {
  printf("Hello 304 from Egorov Alexander a.k.a. swrneko\n☆*:.｡.o(≧▽≦)o.｡.:*☆\n"); 
}
