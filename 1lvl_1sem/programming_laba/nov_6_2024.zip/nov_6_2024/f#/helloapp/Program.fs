﻿// For more information see https://aka.ms/fsharp-console-apps
printfn "Hello 304 from Egorov Alexander a.k.a. swrneko\n☆*:.｡.o(≧▽≦)o.｡.:*☆"
