package main

import "fmt"

func main() {
    fmt.Println("Hello 304 from Egorov Alexander a.k.a. swrneko\n☆*:.｡.o(≧▽≦)o.｡.:*☆")
}

