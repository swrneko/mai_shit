#include <iostream>

int main() { std::cout << "Hello 304 from Egorov Alexander a.k.a. swrneko\n☆*:.｡.o(≧▽≦)o.｡.:*☆\n"; }
