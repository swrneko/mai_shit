using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Hello 304 from Egorov Alexander a.k.a. swrneko\n☆*:.｡.o(≧▽≦)o.｡.:*☆"); // Вывод текста "Hello" на экран
    }
}

